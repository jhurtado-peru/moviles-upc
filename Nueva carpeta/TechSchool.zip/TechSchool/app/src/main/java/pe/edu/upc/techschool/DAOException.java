package pe.edu.upc.techschool;

public class DAOException extends Exception {

    public DAOException(String detailMessage) {
        super(detailMessage);
    }

}
